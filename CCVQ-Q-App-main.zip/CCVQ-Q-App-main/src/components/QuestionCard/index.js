import React, { useEffect, useState } from "react";
import "./index.css";
import { Button } from "@mui/material";

const QuestionCard = ({ questionId, setChoice, questionData }) => {
  const [question, setQuestion] = useState({});
  const [url, setUrl] = useState(window.location.pathname.split("/")[1]); // get round name from url path

  useEffect(() => {
    if(url === "KD")
    {
      const topicId = Math.floor((questionId - 1) / 2);
      const difficult = questionId % 2 === 0 ? 1 : 0;
      // console.log(questionData[topicId].data);
      if(questionData[topicId])
        setQuestion(questionData[topicId].data[difficult]);
    }
    else if(url === "TT")
    {
      if(questionData)
        setQuestion(questionData[questionId].data);
    }
    else if(url === "VCNV")
    {
      if(questionData)
        setQuestion(questionData[questionId].data);
    }
  }, [questionData]);

  return (
    <div className="container">
      <h2>Câu hỏi số {(url === "VCNV" && questionId == 6) ? "Trung tâm" : questionId}</h2>
      <div className="content">
        <h3>Chủ đề: {question ? question.topic : ""} </h3>  
        <p>{question ? question.type : ""}</p>
        <p>{question ? question.question : ""}</p>
        <p>Đáp án: {question ? question.ans : ""}</p>
        {/* <p>Giải thích: {question.explain} </p>
        <p><i>{question.urlQuestion}</i></p>
        <p><i>{question.urlAnswer}</i></p> */}
      </div>
      <div className="button-container">
        <Button variant="contained" color="primary" size="medium" onClick={() => setChoice(questionId)}>
          Sửa
        </Button>
        {/* <Button variant="outlined" color="secondary" size="medium"> 
          Xóa
        </Button> */}
      </div>
    </div>
  );
};

export default QuestionCard;
