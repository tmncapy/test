import * as React from "react";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";

const PlayerPagination = () => {
  return (
    <Stack spacing={2}>
      <Pagination
        count={5}
        shape="rounded"
        color="primary"
        hidePrevButton
        hideNextButton
        centered
        style={{
          display: "flex",
          justifyContent: "center",
        }}
      />
    </Stack>
  );
};
export default PlayerPagination;
