import { useState } from "react";

function TypeButton() {
  // const [isToggled, setIsToggled] = useState(false);
  // const buttonStyle = {
  //   backgroundColor: isToggled ? "Yellow" : "Green",
  //   color: "black",
  //   borderRadius: "10px",
  //   border: "none",
  //   cursor: "pointer",
  //   border: "1px solid black",
  //   padding: 15,
  //   fontSize: 20,
  //   textWidth: "bold",
  // };
  // const toggle = () => {
  //   setIsToggled(!isToggled);
  // };
  // const buttonText = isToggled ? "image" : "text";
  // return (
  //   <button value={buttonText} onClick={toggle} style={buttonStyle}>
  //     {buttonText}
  //   </button>
  // );
  const [selectedButton, setSelectedButton] = useState("image");

  const handleToggle = (value) => {
    setSelectedButton(value);
  };

  return (
    <div>
      <button
        style={{
          backgroundColor: selectedButton === "image" ? "yellow" : "white",
          color: "black",

          borderRadius: "20px",
          padding: "10px 20px",
          marginRight: "10px",
          cursor: "pointer",
          boxShadow:
            selectedButton === "image"
              ? "inset 0 0 5px rgba(0, 0, 0, 0.5)"
              : "none",
        }}
        onClick={() => handleToggle("image")}
        value="image"
      >
        image
      </button>
      <button
        style={{
          backgroundColor: selectedButton === "text" ? "green" : "white",
          color: "black",

          borderRadius: "20px",
          padding: "10px 20px",
          cursor: "pointer",
          boxShadow:
            selectedButton === "text"
              ? "inset 0 0 5px rgba(0, 0, 0, 0.5)"
              : "none",
        }}
        onClick={() => handleToggle("text")}
        value="text"
      >
        text
      </button>
    </div>
  );
}

export default TypeButton;
