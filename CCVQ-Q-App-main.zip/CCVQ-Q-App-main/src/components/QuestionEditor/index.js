import React, { useEffect, useState } from "react";
import { TextField, Select, MenuItem, Snackbar } from "@mui/material";
import "./index.css";
import { Button } from "@mui/material";
// import TypeButton from "./button";
import { styled } from "@mui/system";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { FormControl, InputLabel, Input, FormHelperText } from "@mui/material";
import { type } from "@testing-library/user-event/dist/type";

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const QuestionEditor = ({ questionId, saveData, data }) => {
  const [topics] = useState([
    "Toán",
    "Lý",
    "Hoá",
    "Sinh",
    "Văn",
    "Sử",
    "Địa",
    "Thể thao",
    "Nghệ thuật",
    "Hiểu biết chung",
    "Khác",
    "Anh",
    "Tin",
    "Tự nhiên",
    "Xã hội",
    "Kinh tế",
    "Thiên văn",
    "Pháp luật"
  ]);
  // useless init data.properties -> init in useEffect below
  const [question, setQuestion] = useState(data.question || "");
  const [selectedTopic, setSelectedTopic] = useState(data.topic || "");
  const [questionType, setQuestionType] = useState(data.questionType || "");
  const [urlQuestion, setUrlQuestion] = useState(data.urlQuestion || "");
  const [answer, setAnswer] = useState(data.answer || "");
  const [explain, setExplain] = useState(data.explain || "");
  const [urlAnswer, setUrlAnswer] = useState(data.urlAnswer || "");
  const [hint, setHint] = useState(data.hint || "");
  const [time, setTime] = useState(data.time || "");
  const [timePractical, setTimePractical] = useState(data.timePractical || "");
  const [point, setPoint] = useState(data.value || "  ");

  const [open, setOpen] = useState(false);
  const [url, setUrl] = useState(window.location.pathname.split("/")[1]); // get round name from url path

  const handleSaveData = () => {
    setOpen(true);
    // if (url === "KD") {
    //   saveData = {
    //     question: question,
    //     topic: selectedTopic,
    //     questionType: questionType,
    //     urlQuestion: urlQuestion,
    //     answer: answer,
    //     explain: explain,
    //   }
    // }
    // else if (url === "VCNV") {
    //   saveData = {
    //     question: question,
    //     topic: selectedTopic,
    //     questionType: questionType,
    //     urlQuestion: urlQuestion,
    //     answer: answer,
    //     explain: explain,
    //     urlAnswer: urlAnswer,
    //     hint: hint,
    //   }
    // }
    // else if (url === "TT") {

    // }
    // else if (url === "VD") {

    // }
    // else if (url === "CHST") {

    // }
    saveData(data);

    saveData({
      question: question,
      topic: selectedTopic,
      type: questionType,
      urlQuestion: urlQuestion,
      ans: answer,
      explain: explain,
      urlAnswer: urlAnswer,
      hint: hint,
      time: time,
      time_practical: timePractical,
      value: point
    });
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  // Set the initial data when the component is mounted (question data is passed from QuestionContainer)
  useEffect(() => {
    setQuestion(data.question || "");
    setSelectedTopic(data.topic || "");
    setQuestionType(data.questionType || "");
    setUrlQuestion(data.urlQuestion || "");
    setAnswer(data.answer || "");
    setExplain(data.explain || "");
    setUrlAnswer(data.urlAnswer || "");
    setTime(data.time || "");
    setTimePractical(data.timePractical || "");
    setHint(data.hint || "");
  }, [data])

  return (
    <div  
      className="editor"
      style={{
        border: "1px solid black",
        margin: "1vh 1vh ",
        borderRadius: "20px",
      }}
    >
      <Snackbar
        open={open}
        autoHideDuration={3000}
        onClose={handleClose}
        message="Đã lưu!"
      />
      <div className="outContainer" style={{ margin: "20px" }}>
        {url === "KD" ?
        <h1>Câu hỏi {topics[Math.floor((questionId - 1)/2)]} - {questionId % 2 !== 0 ? "Dễ" : "Khó"}</h1>
        : <h1>Câu hỏi số {(url === "VCNV" && questionId == 6) ? "Trung tâm" : questionId}</h1>
        }
        {["text", "image", "media", "lab"].map((value) => {
          return (
          <Button
            onClick={() => setQuestionType(value)}
            variant= {questionType === value ? "contained" : "outlined" }
            sx={{ margin: "0 10px" }}
          >
            {value}
          </Button>
        )})}

      </div>
      <div
        className="contentContainer"
        style={{
          margin: "20px",
          display: "flex",
          flexDirection: "column",
          gap: "20px",
        }}
      >
        <Select
          labelId="demo-simple-select-label"
          value={selectedTopic}
          label="Topic"
          onChange={(e) => setSelectedTopic(e.target.value)}
        >
          {topics.map((topic) => {
            return <MenuItem value={topic}>{topic}</MenuItem>;
          })}
        </Select>
        <TextField
          label="Câu hỏi"
          variant="outlined"
          multiline
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
        />
        {questionType !== "text" && 
        <div style={{
          display: "grid",
          gap: "20px",
          gridTemplateColumns: "4fr 1fr",
        }}>
          <TextField
            label="URL Câu hỏi"
            variant="outlined"
            value={urlQuestion}
            onChange={(e) => setUrlQuestion(e.target.value)}
          />
          <Button
            component="label"
            role={undefined}
            variant="contained"
            tabIndex={-1}
            // startIcon={<CloudUploadIcon />}
          >
            Upload file
            <VisuallyHiddenInput type="file" onChange={(e) => setUrlQuestion(e.target.files[0].name)}/>
          </Button>
        </div>
        }
        {url === "VD" && 
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={point}
          label="Điểm"
          onChange={(e) => setPoint(e.target.value)}
        >
          <MenuItem value={10}>10</MenuItem>
          <MenuItem value={20}>20</MenuItem>
          <MenuItem value={30}>30</MenuItem>
        </Select>
        }
        <TextField
          label="Đáp án"
          variant="outlined"
          multiline
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
        />
        <TextField
          label="Giải thích"
          variant="outlined"
          multiline
          value={explain}
          onChange={(e) => setExplain(e.target.value)}
        />
        {url === "VCNV" && questionId == 6 && <TextField
          label="Gợi ý"
          variant="outlined"
          multiline
          value={hint}
          onChange={(e) => setHint(e.target.value)}
        />}
        {questionType !== "text" && 
          <div style={{
            display: "grid",
            gap: "20px",
            gridTemplateColumns: "4fr 1fr",
          }}>
            <TextField
              label="Url đáp án"
              variant="outlined"
              value={urlAnswer}
              onChange={(e) => setUrlAnswer(e.target.value)}
            />
            <Button
              component="label"
              role={undefined}
              variant="contained"
              tabIndex={-1}
              // startIcon={<CloudUploadIcon />}
            >
              Upload file
              <VisuallyHiddenInput type="file" onChange={(e) => setUrlAnswer(e.target.files[0].name)}/>
            </Button>
          </div>
        }
        {questionType === "lab" && <TextField
          label="Thời gian suy nghĩ"
          variant="outlined"
          multiline
          value={time}
          onChange={(e) => setTime(e.target.value)}
        />}
        {questionType === "lab" && <TextField
          label="Thời gian thực hành"
          variant="outlined"
          multiline
          value={timePractical}
          onChange={(e) => setTimePractical(e.target.value)}
        />}
        <Button
          variant="contained"
          color="primary"
          size="large"
          sx={{ maxWidth: 10 }}
          onClick={handleSaveData}
        >
          Save
        </Button>
      </div>
    </div>
  );
};
export default QuestionEditor;
