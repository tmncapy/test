import React from "react";
import { Box, Button, Tab, Tabs } from "@mui/material";
import { Link, useLocation } from "react-router-dom";
import PropTypes from "prop-types";

const LinkTab = (props) => {
  const { to } = props;
  const location = useLocation();

  return (
    <Tab
      component={Link}
      to={to}
      aria-current={to === location.pathname ? "page" : undefined}
      {...props}
      sx={{
        paddingRight: 15,
        paddingLeft: 15,
      }}
    />
  );
};

LinkTab.propTypes = {
  label: PropTypes.string.isRequired,
  to: PropTypes.string.isRequired,
};

const exportLog = (data = "ỤA M ĐÃ NHẬP ĐỀ DELL ĐÂU MÀ XUẤT", fileName) => {
  const element = document.createElement("a");
  const file = new Blob([data], {
    type: "text/plain",
  });
  element.href = URL.createObjectURL(file);
  element.download = fileName + ".json";
  document.body.appendChild(element); // Required for this to work in FireFox
  element.click();
};

const Navbar = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleExport = () => {
    const url = window.location.pathname.split("/")[1];
    if(url === "CNV" || url === "VCNV"){
      exportLog(localStorage.getItem("CNV"), "VCNV")
    }
    else if(url === "VD"){
      const data = JSON.parse(localStorage.getItem("VD"));
      const exportData = [{
        data: data
      }]
      exportLog(JSON.stringify(exportData), "VD")
    }
    else {
      exportLog(JSON.stringify(localStorage.getItem(url)), url)
    }
  }

  return (
    <Box sx={{ width: "100%", backgroundColor: "white", boxShadow: 1 }}>
      <Tabs
        value={value}
        onChange={handleChange}
        aria-label="nav tabs example"
        role="navigation"
        centered
      >
        <LinkTab label="Khởi Động" to="/KD" />
        <LinkTab label="Vượt Chướng Ngại Vật" to="/VCNV" />
        <LinkTab label="Tăng Tốc" to="/TT" />
        <LinkTab label="Về Đích" to="/VD" />
        <LinkTab label="Sở trường" to="/CHST" />
        <Button 
          variant="contained" 
          color="primary"
          onClick={handleExport}
        >
          Export
        </Button>
      </Tabs>
    </Box>
  );
};

export default Navbar;
