import React, { useState, useEffect } from "react";
import QuestionCard from "../../components/QuestionCard";
import QuestionEditor from "../../components/QuestionEditor";
import PlayerPagination from "../../components/Pagination";

const defaultTT = JSON.parse(localStorage.getItem("KD")) || [
  { id: 1, data: [{}, {}] },
  { id: 2, data: [{}, {}] },
  { id: 3, data: [{}, {}] },
  { id: 4, data: [{}, {}] },
  { id: 5, data: [{}, {}] },
  { id: 6, data: [{}, {}] },
  { id: 7, data: [{}, {}] },
  { id: 8, data: [{}, {}] },
  { id: 9, data: [{}, {}] },
  { id: 10, data: [{}, {}] },
  { id: 11, data: [{}, {}] },
  { id: 12, data: [{}, {}] },
  { id: 13, data: [{}, {}] },
  { id: 14, data: [{}, {}] },
  { id: 15, data: [{}, {}] },
  { id: 16, data: [{}, {}] }, 
];

const KD = () => {
  const [choice, setChoice] = useState(1);
  const [data, setData] = useState(JSON.parse(localStorage.getItem("KD")) || defaultTT);
  const [questionData, setQuestionData] = useState(defaultTT[0]);
  const [type, setType] = useState(defaultTT[0].data.type || "image");
  const [url, setUrl] = useState(defaultTT[0].data.url);
  const [image, setImage] = useState(defaultTT[0].data.image);

  if(localStorage.getItem("KD") === null) localStorage.setItem("KD", JSON.stringify(defaultTT));

  const saveAnswer = (data) => {
    let tmp = JSON.parse(localStorage.getItem("KD")) || defaultTT;
    // There are easy and difficult questions, so we need to divide the choice by 2 to get the correct topicId
    let topicId = Math.floor((choice - 1) / 2);
    let difficult = choice % 2 === 0 ? 1 : 0;
    tmp[topicId].data[difficult] = {
      // data: data,
      question: data.question,
      topic: data.topic,
      type: data.type,
      urlQuestion: data.urlQuestion,
      ans: data.ans,
      explain: data.explain,
      urlAnswer: data.urlAnswer,
    };
    // console.log(tmp);
    localStorage.setItem("KD", JSON.stringify(tmp));
  };

  const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (err) => {
        reject(err);
      };
    });
  };

  useEffect(() => {
    const tmp = JSON.parse(localStorage.getItem("KD")) || defaultTT;
    setQuestionData(tmp);
  }, [choice])

  return (
    <>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "6fr 4fr",
          height: "90vh",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            height: "80vh",
            marginTop: "1vh",
            marginLeft: "1vh",
            border: "1px solid black",
            borderRadius: "20px",
            paddingBottom: "3vh",
            overflowY: "auto",
          }}
        >
          {/* {[1, 2, 3, 4, 5, 6, 7, 8].map((id) => {
            return <QuestionCard key={id} questionId={id} setChoice={setChoice} />;
          })} */}
          {Array.from({ length: 32 }, (_, i) => i + 1).map((id) => {
            return <QuestionCard key={id} questionId={id} setChoice={setChoice} questionData={questionData}/>;
          })}
        </div>
        <QuestionEditor questionId={choice} saveData={saveAnswer} data={questionData}/>
      </div>
    </>
  );
};
export default KD;
