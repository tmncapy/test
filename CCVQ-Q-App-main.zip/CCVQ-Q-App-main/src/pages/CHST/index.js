import React, { useState, useEffect } from "react";
import QuestionCard from "../../components/QuestionCard";
import QuestionEditor from "../../components/QuestionEditor";
import PlayerPagination from "../../components/Pagination";

const defaultTT = JSON.parse(localStorage.getItem("CHST")) || [
  { id: 1, data: [] },
  { id: 2, data: [] },
  { id: 3, data: [] },
  { id: 4, data: [] },
];

const CHST = () => {
  const [choice, setChoice] = useState(1);
  const [data, setData] = useState(JSON.parse(localStorage.getItem("CHST")) || defaultTT);
  const [questionData, setQuestionData] = useState(defaultTT[0].data);
  const [type, setType] = useState(defaultTT[0].data.type || "image");
  const [url, setUrl] = useState(defaultTT[0].data.url);
  const [image, setImage] = useState(defaultTT[0].data.image);

  if(localStorage.getItem("CHST") === null) localStorage.setItem("CHST", JSON.stringify(defaultTT));

  const saveAnswer = (data) => {

    let tmp = JSON.parse(localStorage.getItem("CHST")) || defaultTT;
    // There are 4 fields so we need to divide the choice by 4 to get the correct topicId
    console.log("So tunog ",tmp)
    let playerId = Math.floor((choice - 1) / 3);
    tmp[playerId].data.push({
      id: data.id,
      topic: data.topic,
      question: data.question,
      ans: data.ans,
      type: data.type,
    });
    // console.log(tmp);
    localStorage.setItem("CHST", JSON.stringify(tmp));
  };

  const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (err) => {
        reject(err);
      };
    });
  };

  useEffect(() => {
    const playerId = Math.floor((choice - 1) / 3);
    setQuestionData(
      JSON.parse(localStorage.getItem("CHST"))[playerId].data ||
        defaultTT[playerId].data
    );
    console.log(questionData);
  }, [choice])

  return (
    <>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "6fr 4fr",
          height: "90vh",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            height: "80vh",
            marginTop: "1vh",
            marginLeft: "1vh",
            border: "1px solid black",
            borderRadius: "20px",
            paddingBottom: "3vh",
            overflowY: "scroll",
          }}
        >
          {/* {[1, 2, 3, 4].map((id) => {
            return <QuestionCard key={id} questionId={id} setChoice={setChoice} />;
          })} */}
          {Array.from({ length: 12 }, (_, i) => i + 1).map((id) => {
            return <QuestionCard key={id} questionId={id} setChoice={setChoice} />;
          })}
        </div>
        <QuestionEditor questionId={choice} saveData={saveAnswer} data={questionData}/>
      </div>
    </>
  );
};
export default CHST;
