import React, { useState } from "react";
import { Button, Divider, TextField } from "@mui/material";
import { styled } from '@mui/material/styles';
import CloudUploadIcon from "@mui/icons-material/CloudUpload";


import Image1 from "./assets/1.png";
import Image2 from "./assets/2.png";
import Image3 from "./assets/3.png";
import Image4 from "./assets/4.png";
import Image5 from "./assets/5.png";
import Center from "./assets/center.png";

import Layer1 from "./assets/Layer1.png";
import Layer2 from "./assets/Layer2.png";
import Layer3 from "./assets/Layer3.png";
import Layer4 from "./assets/Layer4.png";
import LayerCenter from "./assets/LayerCenter.png";

import zIndex from "@mui/material/styles/zIndex";

const ImageStyle = {
    position: "fixed",
    width: "1280px",
    height: "720px",
}
const UploadImageStyle = {
    position: "fixed",
    width: "1280px",
    height: "720px",
    zIndex: -1,
}

const VisuallyHiddenInput = styled('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1,
});

const TestCNV = () => {
    const [isCCVQ, setIsCCVQ] = useState(false);
    const [hint, setHint] = useState("");
    const [answer, setAnswer] = useState("");
    const [url, setUrl] = useState("");
    const [solution, setSolution] = useState("");
    const [type, setType] = useState("image");

    const [image1, setImage1] = useState(true);
    const [image2, setImage2] = useState(true);
    const [image3, setImage3] = useState(true);
    const [image4, setImage4] = useState(true);
    const [image5, setImage5] = useState(true);
    const [image6, setImage6] = useState(true);

    const [uploadImage, setUploadImage] = useState(null);

    const handleOpenPuzzle = (i) => {
        return () => {
            switch(i) {
                case 1:
                    setImage1(!image1);
                    break;
                case 2:
                    setImage2(!image2);
                    break;
                case 3:
                    setImage3(!image3);
                    break;
                case 4:
                    setImage4(!image4);
                    break;
                case 5:
                    setImage5(!image5);
                    break;
                case 6:
                    setImage6(!image6);
                    break;
                default:
                    break;
            }
        }
    }

    const handleChangeRound = () => {
        setIsCCVQ(!isCCVQ);
    }

    const handleSave = () => {
        let data = JSON.parse(localStorage.getItem("VCNV")) || [];
        let CNV = {
            hint: hint,
            answer: answer,
            solution: solution,
            type: type,
        };
        localStorage.setItem(
            "CNV",
            JSON.stringify({ data: data, CNV: { ...CNV, type: "image" } })
        );
    }
    
    return (
        <div
        style={{
            display: "grid",
            gridTemplateColumns: "8fr 2fr",
            padding: "5vh",
        }}
        >
            {isCCVQ ? 
                <div>
                    {image1 && <img src={Image1} alt="test" style={ImageStyle}/>}
                    {image2 && <img src={Image2} alt="test" style={ImageStyle}/>}
                    {image3 && <img src={Image3} alt="test" style={ImageStyle}/>}
                    {image4 && <img src={Image4} alt="test" style={ImageStyle}/>}
                    {image5 && <img src={Image5} alt="test" style={ImageStyle}/>}
                    {image6 && <img src={Center} alt="test" style={ImageStyle}/>}
                    {uploadImage && <img src={URL.createObjectURL(uploadImage)} alt="test" style={UploadImageStyle}/>}
                </div> :
                <div>
                    {image1 && <img src={Layer1} alt="test" style={ImageStyle}/>}
                    {image2 && <img src={Layer2} alt="test" style={ImageStyle}/>}
                    {image3 && <img src={Layer3} alt="test" style={ImageStyle}/>}
                    {image4 && <img src={Layer4} alt="test" style={ImageStyle}/>}
                    {image5 && <img src={LayerCenter} alt="test" style={ImageStyle}/>}
                    {/* {image6 && <img src={Center} alt="test" style={ImageStyle}/>} */}
                    {uploadImage && <img src={URL.createObjectURL(uploadImage)} alt="test" style={UploadImageStyle}/>}
                </div> 

            }
            <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
            }}>
                <Button 
                    variant="contained"
                    color="error" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleChangeRound}
                >
                    {isCCVQ ? "CCVQ" : "TTTL"}
                </Button>
                <Button 
                    variant={image1 === true ? "contained" : "outlined"}
                    color="primary" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleOpenPuzzle(1)}
                >
                    Mở mảnh ghép 1
                </Button>
                <Button 
                    variant={image2 === true ? "contained" : "outlined"}
                    color="primary" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleOpenPuzzle(2)}
                >
                    Mở mảnh ghép 2
                </Button>
                <Button 
                    variant={image3 === true ? "contained" : "outlined"}
                    color="primary" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleOpenPuzzle(3)}
                >
                    Mở mảnh ghép 3
                </Button>
                <Button 
                    variant={image4 === true ? "contained" : "outlined"}
                    color="primary" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleOpenPuzzle(4)}
                >
                    Mở mảnh ghép 4
                </Button>
                <Button 
                    variant={image5 === true ? "contained" : "outlined"}
                    color="primary" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleOpenPuzzle(5)}
                >
                    Mở mảnh ghép 5
                </Button>
                {isCCVQ && 
                <Button 
                    variant={image6 === true ? "contained" : "outlined"}
                    color="primary" 
                    size="large"
                    style={{ 
                        margin: "4px",
                        width: "200px",
                    }}
                    onClick={handleOpenPuzzle(6)}
                >
                    Mở mảnh ghép 6
                </Button>
                }
                <Button
                    component="label"
                    role={undefined}
                    color="success"
                    variant="contained"
                    tabIndex={-1}
                    startIcon={<CloudUploadIcon />}
                    style={{
                        margin: "4px",
                        width: "200px",
                    }}
                >
                    Upload file
                    <VisuallyHiddenInput 
                        type="file" 
                        onChange={(event) => {
                            console.log(event.target.files[0]);
                            setUploadImage(event.target.files[0]);
                        }}
                    />
                </Button>
                
                <Divider />
                <TextField
                    label="Gợi ý ký tự"
                    variant="outlined"
                    multiline
                    value={hint}
                    onChange={(e) => setHint(e.target.value)}
                />
                <TextField
                    label="CNV"
                    variant="outlined"
                    multiline
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value.toUpperCase())}
                />
                <TextField
                    label="Hình ảnh"
                    variant="outlined"
                    multiline
                    value={uploadImage ? uploadImage.name : ""}
                    onChange={(e) => setSolution(e.target.value)}
                />
                <TextField
                    label="Giải thích"
                    variant="outlined"
                    multiline
                    value={solution}
                    onChange={(e) => setSolution(e.target.value)}
                />
                <Button onClick={handleSave()} variant="contained" color="primary">
                    Save
                </Button>
            </div>
        </div>
    );
};

export default TestCNV;
