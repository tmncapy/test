import React, { useState, useEffect } from "react";
import QuestionCard from "../../components/QuestionCard";
import QuestionEditor from "../../components/QuestionEditor";
import PlayerPagination from "../../components/Pagination";
import Fab from '@mui/material/Fab';
import FilterIcon from '@mui/icons-material/Filter';
import { useNavigate } from "react-router-dom";

const defaultTT = JSON.parse(localStorage.getItem("VCNV")) || [
  { id: 1, data: {} },
  { id: 2, data: {} },
  { id: 3, data: {} },
  { id: 4, data: {} },
  { id: 5, data: {} },
  { id: 6, data: {} },
];

const VCNV = () => {
  const [choice, setChoice] = useState(1);
  const [data, setData] = useState(JSON.parse(localStorage.getItem("VCNV")) || defaultTT);
  const [questionData, setQuestionData] = useState(defaultTT[0].data);
  const [type, setType] = useState(defaultTT[0].data.type || "image");
  const [url, setUrl] = useState(defaultTT[0].data.url);
  const [image, setImage] = useState(defaultTT[0].data.image);
  
  const navigate = useNavigate();

  if(localStorage.getItem("VCNV") === null) localStorage.setItem("VCNV", JSON.stringify(defaultTT));

  const saveAnswer = (data) => {
    let tmp = JSON.parse(localStorage.getItem("VCNV")) || defaultTT;
    // tmp[choice - 1].data = { ...data, image } || defaultTT[choice - 1];
    tmp[choice - 1].data = data || defaultTT[choice - 1];
    localStorage.setItem("VCNV", JSON.stringify(tmp));
  };

  const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (err) => {
        reject(err);
      };
    });
  };

  useEffect(() => {
    setQuestionData(
      JSON.parse(localStorage.getItem("VCNV"))[choice - 1].data ||
        defaultTT[choice - 1].data
    );
    console.log(questionData);
  }, [choice])

  return (
    <>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "6fr 4fr",
          height: "90vh",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr 1fr",
            height: "80vh",
            marginTop: "1vh",
            marginLeft: "1vh",
            border: "1px solid black",
            borderRadius: "20px",
            paddingBottom: "3vh",
            overflowY: "scroll",
          }}
        >
          {[1, 2, 3, 4, 5, 6].map((id) => {
            return <QuestionCard key={id} questionId={id} setChoice={setChoice} />;
          })}
        </div>
        <QuestionEditor questionId={choice} saveData={saveAnswer} data={questionData}/>
        <div>
          <Fab 
            color="primary" 
            style={{
              position: "fixed",
              bottom: "20px",
              right: "20px",
            }}
            onClick={() => navigate("/CNV")}
          >
            <FilterIcon />
          </Fab>
        </div>
      </div>
    </>
  );
};
export default VCNV;
