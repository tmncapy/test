import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Header";
import KD from "./pages/KD/index.js";
import VCNV from "./pages/VCNV/index.js";
import TestCNV from "./pages/VCNV/testCNV.js";
import TT from "./pages/TT/index.js";
import VD from "./pages/VD/index.js";
import CHST from "./pages/CHST/index.js";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/KD" element={<KD />} />
        <Route path="/VCNV" element={<VCNV />} />
        <Route path="/TT" element={<TT />} />
        <Route path="/VD" element={<VD />} />
        <Route path="/CHST" element={<CHST />} />
        <Route path="/CNV" element={<TestCNV />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
